<?php
// for connection to MySQL
		$localhost  = 'localhost';
		$cs85Username = 'nyang';
		$cs85Password = 'FHpwj3LTUO';
?>