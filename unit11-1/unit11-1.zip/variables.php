<?php
    global $cs85Username, $cs85Password, $conn, $localhost;
?>